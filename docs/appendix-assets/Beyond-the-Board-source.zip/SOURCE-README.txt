Beyond the Board source and current project materials

The published analysis is available at
https://github.com/CanyonChen/Beyond-the-Board/tree/main
The original benchmark is available at
https://github.com/CanyonChen/Beyond-the-Board/tree/92dd2e7c60d5f3efc5950686f538bdd42e310a98

This archive contains the current analysis source, configuration, audit records and small results tables. It also includes the evaluation-review program and recomputed tables, current report PDF, and complete English presentation script in PDF and editable Markdown.

Use data/README_data.md to obtain the move data. The verified input SHA-256 is 9faf8fd13a2196d4daad9491baa4c1fb735e0cc46a0de7793c206a87a41a554b. The verified data and saved model are available in the published repository. Use the software versions in results/model_comparison/verified_180_0/selection.json for model inference and reproduction.

The review script requires the verified data and saved model from the repository. From the repository root, run python scripts/review_evaluation.py. Its outputs are under results/model_comparison/review_2026_11_23/. The review retains the already examined final-week evaluation period.

The report is docs/report/Beyond_the_Board_Report.pdf. The full English script is docs/Full-Presentation-Script.pdf, with editable text in docs/Full-Presentation-Script.md. Links in the contribution appendix point to the published project materials. This archive contains an offline copy of the source and documents listed above.

SHA256SUMS.txt lists the SHA-256 digest of every other archive entry.
