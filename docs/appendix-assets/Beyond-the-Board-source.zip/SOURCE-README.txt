Beyond the Board source and current project materials

Updated 27 November 2026 from repository revision 9ff3caec2af78318c3c400693d74b63cc124de0f.
Published snapshot:
https://github.com/CanyonChen/Beyond-the-Board/tree/9ff3caec2af78318c3c400693d74b63cc124de0f
Original benchmark:
https://github.com/CanyonChen/Beyond-the-Board/tree/92dd2e7c60d5f3efc5950686f538bdd42e310a98

This archive contains the analysis source, configuration, audit records, small results tables, evaluation-review program and recomputed tables. It also includes both report versions, the current slide PDF and HTML notes, and the complete English presentation script in PDF and editable Markdown.

Current APA-format report: docs/report/Beyond-the-Board-APA-report.pdf
Original eight-page report: docs/report/Beyond_the_Board_Report.pdf
Current slide PDF: docs/pre/Team-SixSixGoSmooth-PPT.pdf
HTML deck with notes: docs/pre/deck.html
English script: docs/Full-Presentation-Script.pdf
Editable English script: docs/Full-Presentation-Script.md

The APA report and slide PDF are byte-identical to repository revision 9ff3caec2af78318c3c400693d74b63cc124de0f. The English script follows the current 7:30 schedule. PDF metadata and text extraction can vary between document versions; the files and hashes identify the archived artifacts.

Use data/README_data.md to obtain the move data. The verified input SHA-256 is 9faf8fd13a2196d4daad9491baa4c1fb735e0cc46a0de7793c206a87a41a554b. The verified data and saved model are available in the published repository. Use the software versions in results/model_comparison/verified_180_0/selection.json for model inference and reproduction.

The review script requires the verified data and saved model from the repository. From the repository root, run python scripts/review_evaluation.py. Its outputs are under results/model_comparison/review_2026_11_23/. The review retains the already examined final-week evaluation period.

Links in the contribution appendix point to published project materials. This archive contains an offline copy of the source and documents listed above. Large move data and fitted models are obtained from the repository rather than duplicated here.

SHA256SUMS.txt lists the SHA-256 digest of every other archive entry.
